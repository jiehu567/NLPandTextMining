import six
__author__ = 'Jie'

import rake
import operator
import io

# EXAMPLE ONE - SIMPLE
stoppath = "SmartStoplist.txt"


print("---------------------------------------------")
# EXAMPLE TWO - BEHIND THE SCENES (from https://github.com/aneesha/RAKE/rake.py)

# 1. initialize RAKE by providing a path to a stopwords file
rake_object = rake.Rake(stoppath)

sample_file = io.open("data/trump1.txt", 'r',encoding="iso-8859-1")
text = sample_file.read()

# 1. Split text into sentences
sentenceList = rake.split_sentences(text)

# generate candidate keywords
stopwordpattern = rake.build_stop_word_regex(stoppath)
phraseList = rake.generate_candidate_keywords(sentenceList, stopwordpattern)
# print("Phrases:", phraseList)
# print("---------------------------------------------")

# calculate individual word scores
wordscores = rake.calculate_word_scores(phraseList)

# generate candidate keyword scores
keywordcandidates = rake.generate_candidate_keyword_scores(phraseList, wordscores)
"""
for candidate in keywordcandidates.keys():
    print "Candidate: %s\t\tscore: %s" % (candidate, keywordcandidates.get(candidate))
"""

# sort candidates by score to determine top-scoring keywords
sortedKeywords = sorted(six.iteritems(keywordcandidates), key=operator.itemgetter(1), reverse=True)
totalKeywords = len(sortedKeywords)

print("---------------------------------------------")
# for example, you could just take the top third as the final keywords
for keyword in sortedKeywords[0:int(totalKeywords / 3)]:
    print "Keyword: %s\tscore: %s" % (keyword[0], keyword[1])

# print(rake_object.run(text))