directory for storing models
